// A blank file used to build the "light" configurations
// This file replaces modules which we do not want to build
// This replacement is done in the "resolve" section of the webpack config
